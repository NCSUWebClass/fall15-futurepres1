use futurepres;

--
-- Table structure for table 'parents'
--

DROP TABLE IF EXISTS parents;
CREATE TABLE parents (
  parentsid int(11) NOT NULL AUTO_INCREMENT,
  parent int(11) NOT NULL,
  child int(11) NOT NULL,
  PRIMARY KEY (parentsid),
  CONSTRAINT page_restrict_parent FOREIGN KEY (parent) REFERENCES pages (pageid) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT page_restrict_child FOREIGN KEY (child) REFERENCES pages (pageid) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;