use futurepres;

--
-- Table structure for table 'eventlog'
--

DROP TABLE IF EXISTS eventlog;
CREATE TABLE eventlog (
  logid int(11) NOT NULL AUTO_INCREMENT,
  ip varchar(45) NOT NULL,
  pageid int(11) NOT NULL,
  dtime DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (logid),
  CONSTRAINT page_restrict_eventlog FOREIGN KEY (pageid) REFERENCES pages (pageid) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;