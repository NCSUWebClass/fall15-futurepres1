use futurepres;

--
-- Table structure for table 'upvotes'
--

DROP TABLE IF EXISTS upvotes;
CREATE TABLE upvotes (
  upvoteid int(11) NOT NULL AUTO_INCREMENT,
  pageid int(11) NOT NULL,
  PRIMARY KEY (upvoteid),
  CONSTRAINT page_restrict_upvotes FOREIGN KEY (pageid) REFERENCES pages (pageid) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;