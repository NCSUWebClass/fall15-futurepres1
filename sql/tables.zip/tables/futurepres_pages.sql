use futurepres;

--
-- Table structure for table 'pages'
--

DROP TABLE IF EXISTS pages;
CREATE TABLE pages (
  pageid int(11) NOT NULL AUTO_INCREMENT,
  name varchar(45) NOT NULL,
  path varchar(255) NOT NULL,
  PRIMARY KEY (pageid)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;